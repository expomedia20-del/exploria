<?php if($response): ?>
<?php echo $response->head; ?>

<?php else: ?>
<?php echo $slot; ?>

<?php endif; ?><?php /**PATH E:\فایل اصلی کمپین تبلیغات خیابانی با نمایشگر\کمپین-1405\فایل 1 اصلی پروژه اکسپلوریا\فایل های تکمیلی قبل از کدنویسی\exploria-codebase\storage\framework\views/58f6b5ecbad88fc4da15879dbc7f6e69.blade.php ENDPATH**/ ?>