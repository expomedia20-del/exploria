<div <?php echo e($attributes->merge(['class' => "h-0 w-full relative"])); ?>>
    <div class="absolute top-[-1px] left-0 right-0 bottom-0 border-t border-dashed border-neutral-300 dark:border-white/[9%]"></div>
</div>
<?php /**PATH E:\فایل اصلی کمپین تبلیغات خیابانی با نمایشگر\کمپین-1405\فایل 1 اصلی پروژه اکسپلوریا\فایل های تکمیلی قبل از کدنویسی\exploria-codebase\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/separator.blade.php ENDPATH**/ ?>