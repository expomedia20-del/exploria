import Auth from './Auth'
import ConsentController from './ConsentController'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
ConsentController: Object.assign(ConsentController, ConsentController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers