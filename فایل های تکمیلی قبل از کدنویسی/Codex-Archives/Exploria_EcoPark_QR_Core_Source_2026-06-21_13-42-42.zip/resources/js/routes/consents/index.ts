import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
export const current = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})

current.definition = {
    methods: ["get","head"],
    url: '/api/v1/consents/current',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
current.url = (options?: RouteQueryOptions) => {
    return current.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
current.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
current.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: current.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
    const currentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: current.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
        currentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: current.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ConsentController::current
 * @see app/Http/Controllers/ConsentController.php:13
 * @route '/api/v1/consents/current'
 */
        currentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: current.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    current.form = currentForm
/**
* @see \App\Http\Controllers\ConsentController::accept
 * @see app/Http/Controllers/ConsentController.php:36
 * @route '/api/v1/consents/accept'
 */
export const accept = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(options),
    method: 'post',
})

accept.definition = {
    methods: ["post"],
    url: '/api/v1/consents/accept',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ConsentController::accept
 * @see app/Http/Controllers/ConsentController.php:36
 * @route '/api/v1/consents/accept'
 */
accept.url = (options?: RouteQueryOptions) => {
    return accept.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ConsentController::accept
 * @see app/Http/Controllers/ConsentController.php:36
 * @route '/api/v1/consents/accept'
 */
accept.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ConsentController::accept
 * @see app/Http/Controllers/ConsentController.php:36
 * @route '/api/v1/consents/accept'
 */
    const acceptForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ConsentController::accept
 * @see app/Http/Controllers/ConsentController.php:36
 * @route '/api/v1/consents/accept'
 */
        acceptForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(options),
            method: 'post',
        })
    
    accept.form = acceptForm
const consents = {
    current: Object.assign(current, current),
accept: Object.assign(accept, accept),
}

export default consents