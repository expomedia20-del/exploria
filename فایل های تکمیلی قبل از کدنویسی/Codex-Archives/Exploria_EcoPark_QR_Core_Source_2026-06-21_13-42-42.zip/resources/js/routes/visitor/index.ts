import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
export const otp = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: otp.url(options),
    method: 'get',
})

otp.definition = {
    methods: ["get","head"],
    url: '/access',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
otp.url = (options?: RouteQueryOptions) => {
    return otp.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
otp.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: otp.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
otp.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: otp.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
    const otpForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: otp.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
        otpForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: otp.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/access'
 */
        otpForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: otp.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    otp.form = otpForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
export const consent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consent.url(options),
    method: 'get',
})

consent.definition = {
    methods: ["get","head"],
    url: '/consent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
consent.url = (options?: RouteQueryOptions) => {
    return consent.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
consent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consent.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
consent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: consent.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
    const consentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: consent.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
        consentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consent.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/consent'
 */
        consentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    consent.form = consentForm
const visitor = {
    otp: Object.assign(otp, otp),
consent: Object.assign(consent, consent),
}

export default visitor